# test_app.py
import pytest
from app import calculate_discount

def test_standard_discount():
    assert calculate_discount(100, 20) == 80.0

def test_full_discount():
    assert calculate_discount(50, 100) == 0.0

def test_invalid_parameters():
    with pytest.raises(ValueError):
        calculate_discount(-10, 10)
    with pytest.raises(ValueError):
        calculate_discount(100, 150)
        
# Este archivo es resultado del Sub-Agent Test-Driven Development de Superpowers
# El agente primero escribe esto y luego escribe el app.py (TDD).
